function getData()
{
    var get=new XMLHttpRequest(); // create request 
    // api
    get.open('GET','http://localhost:7777/getdata')


    get.onreadystatechange=function()
    {
        if(get.status==200&&get.readyState==4)
        {
          document.getElementById('div').innerText=this.responseText;
        }
    }

    get.send(); // send  request 
}